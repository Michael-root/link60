// js控制多端响应样式
	function bannchange(){
		var banwid=$(window).width();
		if(banwid<975){
			//导航的隐藏
			$("#navbar-menu").css({"display":"none"});
		}else{
			$("#navbar-menu").css({"display":"block"});
		}
	}
	bannchange();
	$(window).resize(function(){
		bannchange();
	})

	